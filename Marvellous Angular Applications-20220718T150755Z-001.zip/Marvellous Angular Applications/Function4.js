function main() {
    console.log("Inside main");
    fun();
    console.log("End of main");
}
function fun() {
    console.log("Inside fun");
}
main();
