// Loop : for , while , do-while
function Sequance() {
    console.log("Hello");
    console.log("Hello");
    console.log("Hello");
    console.log("Hello");
    console.log("Hello");
}
function Iteration_For() {
    var i = 0;
    for (i = 1; i <= 5; i++) {
        console.log("Hello");
    }
}
function Iteration_While() {
    var i = 1;
    while (i <= 5) {
        console.log("Hello");
        i++;
    }
}
Sequance();
Iteration_For();
Iteration_While();
