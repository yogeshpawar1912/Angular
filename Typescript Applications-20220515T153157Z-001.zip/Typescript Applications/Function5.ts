function main() : void
{
    console.log("Inside main");
    fun();
    console.log("End of main");
}

function fun() : void
{
    console.log("Inside fun");
}

main();