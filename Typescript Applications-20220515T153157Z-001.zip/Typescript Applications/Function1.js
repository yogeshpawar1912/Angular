function fun() {
    console.log("Inside fun");
}
fun(); // Function call
