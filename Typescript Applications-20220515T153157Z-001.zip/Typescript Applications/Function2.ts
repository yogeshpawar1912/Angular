function Display(value)
{
    console.log("Parameter is : "+value);
}

var no : number = 11;
Display(no);    