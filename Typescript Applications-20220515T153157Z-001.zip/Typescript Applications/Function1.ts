function fun() : void          // Function defination
{
    console.log("Inside fun");
}

fun();      // Function call