// Defination of add function

function add(no1:number,no2:number):number 
{  
    var ans:number;

    ans = no1+no2;
    
    return ans; 
}  

var iret:number;
iret = add(10,1);

console.log("Addition is :"+iret);