 
function ChkEvenOdd(num:number) 
{ 
    if (num % 2 == 0) 
    {
        console.log("Even");
    } 
    else 
    {
        console.log("Odd");
    }      
 }

var no = 12;

ChkEvenOdd(no);


