// Variable declared with data type and initialization
var name1:string = "Marvellous Infosystems";

// Variable declared with data type only.
var name2:string;

// Variable declared without data type. Data type is predicted upon the initialization
var name3 = "Marvellous Infosystems";

// Data type is considered as any
var name4;
 