// int no = 11;     C/ C++/ Java/ C#

var a1 = 11;        // js        ts

var a2 : number = 11;       // ts

// number -> int , float, double, short, long

console.log(a1);
console.log(a2);