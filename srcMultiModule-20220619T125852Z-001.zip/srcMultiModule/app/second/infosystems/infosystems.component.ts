import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-infosystems',
  templateUrl: './infosystems.component.html',
  styleUrls: ['./infosystems.component.css']
})
export class InfosystemsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
