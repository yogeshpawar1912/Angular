function Display(value) {
    console.log("Parameter is : " + value);
}
var no = 11;
Display(no);
