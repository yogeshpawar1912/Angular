function main() : void      // Function Defination
{
    console.log("Inside main");
    fun();              // Function call
    console.log("End of main");
}

function fun() : void           // Function Defination
{
    console.log("Inside fun");
}

main();     // Function call
