var no : number = 11;                   // int no = 11;
var str : string = "Jay Ganesh...";
console.log(str);   // Display on console
console.log(no);